SEXVIP — giao diện website tĩnh

CÁCH ĐƯA LÊN GITHUB PAGES (điện thoại):
1. Tải file sexvip-github-pages.zip và giải nén trong ứng dụng Tệp.
2. Mở repository GitHub bạn đã tạo (theo ảnh, tên repository là SexVip).
3. Bấm Add file > Upload files > chọn file index.html đã giải nén.
4. Bấm Commit changes.
5. Mở Settings > Pages > Build and deployment.
6. Chọn Deploy from a branch; Branch: main; Folder: /(root); bấm Save.
7. Đợi GitHub công bố địa chỉ website.

CHỈNH SỬA:
- Đổi tên trang: sửa chữ SEXVIP.COM ở <a class="logo">.
- Sửa tên/tiêu đề video trong các thẻ <h2> và data-title.
- Thay phần <div class="thumb"> bằng ảnh của bạn, ví dụ:
  <img class="thumb" src="images/anh1.jpg" alt="Ảnh đại diện">
  Nếu dùng ảnh riêng, hãy tải ảnh lên repository trong thư mục images.
- Đổi href="#" thành đường dẫn video/trang xem mà bạn sở hữu hoặc có quyền sử dụng.
- Các danh mục và tìm kiếm lọc các video mẫu. Phân trang tự hiện khi có nhiều video hơn số đang hiển thị.

LƯU Ý:
- GitHub Pages chỉ lưu trang tĩnh; không có tài khoản, cơ sở dữ liệu hay nơi lưu video riêng.
- Không đăng nội dung vi phạm bản quyền, không có sự đồng ý của người xuất hiện, hoặc nội dung bất hợp pháp.
